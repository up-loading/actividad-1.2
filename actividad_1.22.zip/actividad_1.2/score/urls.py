# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.mi_vista, name='mi_vista'),
    path('about/', views.about, name='about'),  # Ruta adicional como ejemplo
]
