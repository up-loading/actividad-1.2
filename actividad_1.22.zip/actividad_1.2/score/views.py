
from django.shortcuts import render

def mi_vista(request):
    contexto = {
        'nombre': 'Juan',
        'items': ['Manzana', 'Banana', 'Cereza']
    }
    return render(request, 'mi_template.html', contexto)

def about(request):
    return render(request, 'about.html')
